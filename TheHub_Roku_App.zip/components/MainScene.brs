sub init()
    m.channelList = m.top.findNode("channelList")
    m.videoPlayer = m.top.findNode("videoPlayer")
    
    m.channelList.observeField("rowItemSelected", "onChannelSelect")
    m.videoPlayer.observeField("state", "onPlayerStateChange")
    
    ' Focus the grid on startup
    m.channelList.setFocus(true)
    
    ' Load home feed on startup (empty query = recently cached videos)
    sendSearchToComputer("")
end sub

sub openSearchBox()
    m.keyboard = CreateObject("roSGNode", "KeyboardDialog")
    m.keyboard.title = "Search The Hub (BADINFLUNCEYT)"
    m.keyboard.buttons = ["Search", "Cancel"]
    m.keyboard.observeField("buttonSelected", "onSearchButtonPress")
    m.top.dialog = m.keyboard
end sub

sub onSearchButtonPress()
    if m.keyboard.buttonSelected = 0
        queryText = m.keyboard.text
        m.top.dialog = invalid
        if queryText <> ""
            sendSearchToComputer(queryText)
        end if
    else
        m.top.dialog = invalid
        m.channelList.setFocus(true)
    end if
end sub

sub sendSearchToComputer(searchQuery as String)
    ' ── UPDATE THIS IP if your computer's local IP changes ──
    computerIP = "192.168.0.142"
    serverPort = "5002"

    apiUrl = "http://" + computerIP + ":" + serverPort + "/api/roku/search?q=" + searchQuery.EncodeUriComponent()
    print "[HUB] Fetching: " + apiUrl

    m.searchTask = CreateObject("roSGNode", "SearchTask")
    m.searchTask.url = apiUrl
    m.searchTask.observeField("results", "onResultsReturned")
    m.searchTask.control = "RUN"
end sub

sub onResultsReturned()
    sections = m.searchTask.results
    if sections = invalid or sections.count() = 0
        print "[HUB] No results or categories returned from server"
        return
    end if

    ' Root node required by the RowList component
    rootContent = CreateObject("roSGNode", "ContentNode")

    ' Loop through each category row sent by your Python backend
    for each section in sections
        rowNode = rootContent.CreateChild("ContentNode")
        rowNode.title = section.row_title

        ' Loop through each individual video inside this specific category
        for each item in section.items
            node = rowNode.CreateChild("ContentNode")

            ' Title mapping
            if item.title <> invalid and item.title <> ""
                node.title = item.title
            else
                node.title = "Untitled"
            end if

            ' Stream URL routing
            if item.url <> invalid and item.url <> ""
                node.url = item.url
            else
                node.url = ""
            end if

            ' Format tracking
            if item.streamformat <> invalid and item.streamformat <> ""
                node.streamformat = item.streamformat
            else
                node.streamformat = "mp4"
            end if

            ' Thumbnail selection - with a default poster asset fallback
            if item.thumbnail <> invalid and item.thumbnail <> ""
                node.hdposterurl = item.thumbnail
            else if item.HDPosterUrl <> invalid and item.HDPosterUrl <> ""
                node.hdposterurl = item.HDPosterUrl
            else
                ' This is your safety net. If Python has no thumbnail, it uses this local image.
                node.hdposterurl = "pkg:/images/placeholder.png"
            end if

            ' Author text description mapping - matches your original python schema keys
            if item.author <> invalid and item.author <> ""
                node.shortDescriptionLine2 = item.author
            else
                node.shortDescriptionLine2 = "Hub Creator"
            end if
        end for
    end for

    ' Attach the multi-row tree structure to your UI grid component
    m.channelList.content = rootContent
    m.channelList.setFocus(true)
    print "[HUB] UI refreshed with " + sections.count().toStr() + " polished categorical rows."
end sub

sub onChannelSelect()
    indices = m.channelList.rowItemSelected
    if indices = invalid or indices.count() < 2 then return

    rowContent = m.channelList.content.getChild(indices[0])
    if rowContent = invalid then return

    videoData = rowContent.getChild(indices[1])
    if videoData = invalid or videoData.url = "" then return

    print "[HUB] Playing: " + videoData.title
    print "[HUB] Stream URL: " + videoData.url

    videoContent = CreateObject("roSGNode", "ContentNode")
    videoContent.url = videoData.url
    videoContent.streamformat = videoData.streamformat

    ' Hand the content to the Video node and start playback
    m.videoPlayer.content = videoContent
    m.videoPlayer.visible = true
    m.videoPlayer.control = "play"
    m.videoPlayer.setFocus(true)
end sub

sub onPlayerStateChange()
    state = m.videoPlayer.state
    print "[HUB] Player state: " + state

    if state = "finished"
        ' Video ended — go back to the grid
        m.videoPlayer.control = "stop"
        m.videoPlayer.visible = false
        m.channelList.setFocus(true)
    else if state = "error"
        print "[HUB] Playback error: " + m.videoPlayer.errorMsg
        m.videoPlayer.control = "stop"
        m.videoPlayer.visible = false
        m.channelList.setFocus(true)
    end if
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    handled = false
    if press then
        if key = "back"
            if m.videoPlayer.visible = true
                m.videoPlayer.control = "stop"
                m.videoPlayer.visible = false
                m.channelList.setFocus(true)
                handled = true
            end if
        else if key = "options"
            ' Star (*) button opens search
            openSearchBox()
            handled = true
        end if
    end if
    return handled
end function